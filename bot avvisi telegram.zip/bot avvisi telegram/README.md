# 🏭 Telegram Bot Multi-Impianto

Bot Telegram privato per la gestione di impianti industriali con autenticazione telefonica,
blacklist, notifiche di allarme e API HTTP per l'integrazione con sistemi esterni.

---

## Architettura

```
telegram-bot/
├── main.py              # Entrypoint – avvia DB + bot + API server
├── bot/
│   ├── handlers.py      # Tutti i comandi Telegram
│   ├── auth.py          # Middleware autenticazione
│   └── manager.py       # Gestione multi-bot (un'istanza per impianto)
├── api/
│   └── server.py        # FastAPI – riceve avvisi dall'esterno
├── db/
│   ├── database.py      # Pool asyncpg + query helpers
│   └── schema.sql       # Schema PostgreSQL
├── scripts/
│   └── setup.py         # Setup iniziale DB + dati di esempio
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Avvio rapido

### 1. Prerequisiti
- Python 3.12+
- PostgreSQL 14+ (oppure Docker)
- Un bot Telegram per ogni impianto (crea con [@BotFather](https://t.me/BotFather))

### 2. Configurazione

```bash
cp .env.example .env
# Modifica .env con DATABASE_URL e API_SECRET
```


### 3. Installazione

```bash
pip install -r requirements.txt
python scripts/setup.py   # crea schema + dati di esempio
python main.py
```

---

## Gestione impianti

Ogni impianto è una riga nella tabella `impianti` con il proprio `bot_token`.
Il manager avvia automaticamente un'istanza bot per ciascun impianto attivo.

**Aggiungere un impianto:**
```sql
INSERT INTO impianti(nome, bot_token, descrizione)
VALUES ('impiantoXyz', 'TOKEN_DA_BOTFATHER', 'Descrizione impianto');
```
Poi riavvia il servizio (o implementa il ricaricamento a caldo).

---

## Gestione utenti

**Aggiungere un utente autorizzato:**
```sql
INSERT INTO utenti_autorizzati(impianto_id, telefono, nome, ruolo)
VALUES (1, '+39XXXXXXXXXX', 'Nome Cognome', 'operatore');
-- ruolo: operatore | supervisore | admin
```

**Flusso di accesso utente:**
1. L'utente apre il bot e invia `/start`
2. Il bot chiede di condividere il numero di telefono
3. Il numero viene verificato contro blacklist e whitelist
4. Se autorizzato, il `telegram_id` viene associato all'utente
5. L'utente può usare tutti i comandi

---

## Blacklist

Quando un dipendente viene licenziato o spostato:

**Via comando Telegram (admin):**
```
/blocca +39XXXXXXXXXX Licenziamento
```

**Via API:**
```bash
curl -X POST http://localhost:8000/blacklist \
  -H "X-Api-Key: TUA_CHIAVE" \
  -H "Content-Type: application/json" \
  -d '{"telefono": "+39XXXXXXXXXX", "motivo": "Licenziamento", "aggiunto_da": "HR"}'
```

**Effetti:** il numero viene inserito nella blacklist globale e l'utente viene disattivato
su tutti gli impianti. Al prossimo messaggio riceverà un avviso di accesso revocato.

---

## API HTTP – Invio Avvisi

### Autenticazione
Tutte le chiamate richiedono l'header `X-Api-Key: <API_SECRET>`.

### POST /avvisi

Invia un avviso a tutti gli utenti autenticati di un impianto.

```bash
curl -X POST http://localhost:8000/avvisi \
  -H "X-Api-Key: TUA_CHIAVE" \
  -H "Content-Type: application/json" \
  -d '{
    "impianto_nome": "impiantoAcme",
    "tipo":          "allarme",
    "titolo":        "Temperatura critica – Linea A",
    "messaggio":     "Sensore T-04 ha rilevato 98°C (soglia: 90°C)",
    "severita":      4,
    }
  }'
```

**Campi severità:**
| Valore | Emoji | Label   |
|--------|-------|---------|
| 1      | ℹ️    | Info    |
| 2      | ⚠️    | Warning |
| 3      | 🔴    | Errore  |
| 4      | 🆘    | CRITICO |


---

## Comandi Telegram

| Comando | Accesso | Descrizione |
|---------|---------|-------------|
| `/start` | Tutti | Autenticazione con numero telefono |
| `/help` | Autorizzati | Lista comandi disponibili |
| `/status` | Autorizzati | Stato impianto + ultimi avvisi |
| `/allarmi` | Autorizzati | Ultimi 10 avvisi |
| `/io` | Autorizzati | Info account personale |
| `/utenti` | Supervisore+ | Lista utenti autorizzati |
| `/blacklist` | Admin | Mostra blacklist |
| `/blocca <tel> <motivo>` | Admin | Aggiunge alla blacklist |
| `/sblocca <tel>` | Admin | Rimuove dalla blacklist |

---

## Sicurezza

- Il bot accetta messaggi solo da utenti con `telegram_id` registrato
- La blacklist è verificata ad ogni comando (non solo al login)
- L'API HTTP è protetta da chiave segreta nell'header
- Tutti gli accessi e i comandi sono loggati nel DB
- I token bot devono essere tenuti segreti (non committarli su Git!)
