import os
import json
import httpx
import shutil
import time
import mysql.connector
CARTELLA = "risposte_utenti"
CARTELLA_INVIATI = "risposte_inviate"
CARTELLA_IGNORATI = "risposte_ignorate"
ENDPOINT = "http://localhost:5050/api/risposte"   
db = mysql.connector.connect(       
    host="localhost",       
    user="root",                
    password="",        
    database="prototipo"
)       
cursor = db.cursor()        
os.makedirs(CARTELLA_INVIATI, exist_ok=True)        
os.makedirs(CARTELLA_IGNORATI, exist_ok=True)       
print("🔄 Monitor attivo. In attesa di nuovi file...")      
while True:     
    for filename in os.listdir(CARTELLA):       
        if not filename.endswith(".json"):      
            continue        
        filepath = os.path.join(CARTELLA, filename)     
        with open(filepath, "r", encoding="utf-8") as f:        
            data = json.load(f)     
        telefono = data.get("telefono")            
        cursor.execute(     
            "SELECT ruolo FROM utenti_autorizzati WHERE telefono = %s",     
            (telefono,)     
        )       
        row = cursor.fetchone()     
        if not row:     
            print(f"⛔ Utente non trovato nel DB ({telefono}). Ignorato.")      
            shutil.move(filepath, os.path.join(CARTELLA_IGNORATI, filename))        
            continue        
        ruolo = row[0].lower()          
        if ruolo != "admin":        
            print(f"⛔ Utente NON admin (ruolo: {ruolo}). File ignorato.")      
            shutil.move(filepath, os.path.join(CARTELLA_IGNORATI, filename))        
            continue            
        print(f"📄 File admin trovato: {filename}")     
        print("➡️  Invio all'endpoint:", data)      
        try:        
            response = httpx.post(ENDPOINT, json=data, timeout=10)      
            print("✅ Risposta server:", response.text)     
            shutil.move(filepath, os.path.join(CARTELLA_INVIATI, filename))     
            print("📦 File spostato in risposte_inviate\n")     
        except Exception as e:      
            print("❌ Errore invio:", e)        
    time.sleep(2)       