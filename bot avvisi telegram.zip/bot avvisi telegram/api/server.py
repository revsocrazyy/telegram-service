import logging      
import os       
from typing import Optional     
from fastapi import FastAPI, HTTPException, Header, Depends     
from fastapi.middleware.cors import CORSMiddleware      
from pydantic import BaseModel, Field       
from telegram import Bot        
from db import database as db       
from bot.manager import get_application     
logger = logging.getLogger(__name__)        
app = FastAPI(      
    title="Telegram Bot – API",     
    description="Gestione avvisi, blacklist e registrazione utenti",        
    version="1.0.0",        
)       
app.add_middleware(     
    CORSMiddleware,     
    allow_origins=["*"],        
    allow_methods=["*"],        
    allow_headers=["*"],        
)       
API_SECRET = os.environ.get("API_SECRET", "cambia_questa_chiave")       
SEVERITA_EMOJI = {1: "ℹ️", 2: "⚠️", 3: "🔴", 4: "🆘"}     
SEVERITA_LABEL  = {1: "Info", 2: "Warning", 3: "Errore", 4: "CRITICO"}      
class AvvisoRequest(BaseModel):     
    impianto_nome:  str            = Field(...)     
    tipo:           str            = Field(...)     
    titolo:         str            = Field(...)     
    messaggio:      Optional[str]  = None       
    severita:       int            = Field(1, ge=1, le=4)       
    source:         Optional[str]  = None       
    extra:          Optional[dict] = None       
class BlacklistRequest(BaseModel):      
    telefono:    str        
    motivo:      Optional[str] = "Rimosso via API"      
    aggiunto_da: Optional[str] = "sistema"      
class RegistrazioneRequest(BaseModel):      
    impianto_nome: str = Field(..., description="Nome esatto dell'impianto")        
    telefono:      str = Field(..., description="Numero telefono es. +39XXXXXXXXXX")        
    nome:          str = Field(..., description="Nome e cognome")       
    ruolo:         str = Field("operatore", description="operatore | supervisore | admin")      
class RispostaOk(BaseModel):        
    ok:           bool = True       
    messaggio:    str       
    avviso_id:    Optional[int] = None      
class RegistrazioneRisposta(BaseModel):     
    ok:           bool = True       
    messaggio:    str       
    utente_id:    int       
    bot_username: Optional[str] = None      
def verifica_api_key(x_api_key: str = Header(...)):     
    if x_api_key != API_SECRET:     
        raise HTTPException(status_code=401, detail="API key non valida")       
    return x_api_key        
@app.get("/impianti", tags=["Impianti"])        
async def lista_impianti(_: str = Depends(verifica_api_key)):       
    impianti = await db.get_tutti_impianti()        
    return [{"nome": i["nome"], "descrizione": i["descrizione"]} for i in impianti]     
@app.post("/registra", response_model=RegistrazioneRisposta, tags=["Utenti"])       
async def registra_utente(payload: RegistrazioneRequest, _: str = Depends(verifica_api_key)):       
    import re       
    telefono = re.sub(r"[\s\-\(\)]", "", payload.telefono)      
    if not telefono.startswith("+"):        
        telefono = "+" + telefono       
    pool = db.get_pool()        
    async with pool.acquire() as conn:      
        async with conn.cursor(db_cursor_class()) as cur:       
            await cur.execute(      
                "SELECT id, bot_token FROM impianti WHERE nome=%s AND attivo=1",        
                (payload.impianto_nome,)        
            )       
            imp = await cur.fetchone()      
    if not imp:     
        raise HTTPException(status_code=404, detail=f"Impianto '{payload.impianto_nome}' non trovato")      
    impianto_id = imp["id"]     
    bot_token   = imp["bot_token"]      
    if await db.is_in_blacklist(telefono):      
        raise HTTPException(status_code=403, detail="Numero in blacklist")      
    if payload.ruolo not in ("operatore", "supervisore", "admin"):      
        raise HTTPException(status_code=400, detail="Ruolo non valido")
    async with pool.acquire() as conn: 
        async with conn.cursor() as cur:   
            await cur.execute( 
                """INSERT INTO utenti_autorizzati(impianto_id, telefono, nome, ruolo)  
                   VALUES(%s, %s, %s, %s)  
                   ON DUPLICATE KEY UPDATE nome=VALUES(nome), ruolo=VALUES(ruolo), attivo=1""",
                (impianto_id, telefono, payload.nome.strip(), payload.ruolo)   
            )  
            utente_id = cur.lastrowid or 0 
    bot_username = None
    try:   
        bot_obj = Bot(token=bot_token) 
        me = await bot_obj.get_me()     
        bot_username = me.username      
    except Exception as e:      
        logger.warning(f"Impossibile recuperare username bot: {e}")     
    logger.info(f"Utente registrato: {telefono} su {payload.impianto_nome} (ruolo={payload.ruolo})")        
    return RegistrazioneRisposta(       
        messaggio  = f"Utente {payload.nome} registrato su {payload.impianto_nome}",        
        utente_id  = utente_id,     
        bot_username = bot_username,        
    )       
@app.post("/avvisi", response_model=RispostaOk, tags=["Avvisi"])        
async def invia_avviso(payload: AvvisoRequest, _: str = Depends(verifica_api_key)):     
    pool = db.get_pool()        
    async with pool.acquire() as conn:      
        async with conn.cursor(db_cursor_class()) as cur:       
            await cur.execute(      
                "SELECT * FROM impianti WHERE nome=%s AND attivo=1", (payload.impianto_nome,)       
            )       
            imp = await cur.fetchone()      
    if not imp:     
        raise HTTPException(status_code=404, detail=f"Impianto '{payload.impianto_nome}' non trovato")      
    impianto_id = imp["id"]     
    avviso_id = await db.crea_avviso(       
        impianto_id=impianto_id, tipo=payload.tipo, titolo=payload.titolo,      
        messaggio=payload.messaggio or "", severita=payload.severita,       
        source=payload.source, extra_json=payload.extra,        
    )       
    emoji  = SEVERITA_EMOJI.get(payload.severita, "ℹ️")      
    label  = SEVERITA_LABEL.get(payload.severita, "?")      
    tg_msg = f"{emoji} *{label.upper()} – {payload.titolo}*\n🏭 _{imp['nome']}_\n"      
    if payload.source:      
        tg_msg += f"📡 `{payload.source}`\n"        
    if payload.messaggio:       
        tg_msg += f"\n{payload.messaggio}\n"        
    utenti  = await db.get_utenti_impianto(impianto_id)     
    app_bot = get_application(impianto_id)      
    inviati = 0     
    if app_bot:     
        bot: Bot = app_bot.bot      
        for u in utenti:        
            if u["telegram_id"]:        
                try:        
                    await bot.send_message(chat_id=u["telegram_id"], text=tg_msg, parse_mode="Markdown")        
    
                    app_bot.bot_data.setdefault("attesa_risposta", {})[u["telegram_id"]] = {        
                        "avviso_id":   avviso_id,       
                        "titolo":      payload.titolo,      
                        "mittente_id": None,        
                    }       
                    inviati += 1        
                except Exception as e:      
                    logger.error(f"Errore invio a {u['telegram_id']}: {e}")     
    await db.marca_avviso_inviato(avviso_id)        
    return RispostaOk(messaggio=f"Avviso inviato a {inviati} utenti", avviso_id=avviso_id)      
@app.post("/blacklist", response_model=RispostaOk, tags=["Blacklist"])      
async def aggiungi_blacklist(payload: BlacklistRequest, _: str = Depends(verifica_api_key)):        
    await db.aggiungi_a_blacklist(payload.telefono, payload.motivo, payload.aggiunto_da)        
    return RispostaOk(messaggio=f"Numero {payload.telefono} aggiunto alla blacklist")       
@app.delete("/blacklist/{telefono}", response_model=RispostaOk, tags=["Blacklist"])     
async def rimuovi_blacklist(telefono: str, _: str = Depends(verifica_api_key)):     
    await db.rimuovi_da_blacklist(telefono)     
    return RispostaOk(messaggio=f"Numero {telefono} rimosso dalla blacklist")       
@app.get("/health", tags=["Sistema"])       
async def health():     
    return {"status": "ok"}     
def db_cursor_class():      
    import aiomysql     
    return aiomysql.DictCursor      
@app.get("/utenti", tags=["Utenti"])        
async def lista_utenti(impianto: Optional[str] = None, _: str = Depends(verifica_api_key)):     
    pool = db.get_pool()        
    async with pool.acquire() as conn:      
        async with conn.cursor(db_cursor_class()) as cur:       
            if impianto:        
                await cur.execute(      
                    """SELECT u.*, i.nome as impianto_nome      
                       FROM utenti_autorizzati u        
                       JOIN impianti i ON i.id = u.impianto_id      
                       WHERE i.nome = %s AND u.attivo = 1       
                       ORDER BY u.created_at DESC""",       
                    (impianto,)     
                )       
            else:       
                await cur.execute(      
                    """SELECT u.*, i.nome as impianto_nome      
                       FROM utenti_autorizzati u        
                       JOIN impianti i ON i.id = u.impianto_id      
                       WHERE u.attivo = 1       
                       ORDER BY u.created_at DESC"""        
                )       
            rows = await cur.fetchall()     
    return [dict(r) for r in rows]      
@app.get("/blacklist", tags=["Blacklist"])      
async def get_blacklist(_: str = Depends(verifica_api_key)):        
    lista = await db.get_blacklist()        
    return lista        