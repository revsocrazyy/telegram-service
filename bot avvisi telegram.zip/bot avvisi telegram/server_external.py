from fastapi import FastAPI
from pydantic import BaseModel 
import uvicorn 
app = FastAPI()
ULTIMA_RISPOSTA = {"utente": "", "risposta": ""}   
class Risposta(BaseModel): 
    utente: str
    telefono: str  
    risposta: str  
@app.post("/api/risposte") 
async def ricevi_risposta(payload: Risposta):  
    global ULTIMA_RISPOSTA 
    ULTIMA_RISPOSTA = {
        "utente": payload.utente,  
        "risposta": payload.risposta   
    }  
    print(f"📩 Risposta ricevuta da {payload.utente}: {payload.risposta}") 
    return payload.risposta
@app.get("/vedi-risposta")
async def vedi_risposta():
    return ULTIMA_RISPOSTA
if __name__ == "__main__":
    uvicorn.run("server_external:app", host="0.0.0.0", port=5050, reload=True) 