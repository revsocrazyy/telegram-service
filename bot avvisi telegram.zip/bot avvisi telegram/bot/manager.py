import asyncio     
import logging     
from typing import Dict    
from telegram.ext import Application       
from bot.handlers import build_handlers    
from bot.auth import IMPIANTO_KEY      
from db import database as db      
logger = logging.getLogger(__name__)       
_bots: Dict[str, Application] = {}     
async def avvia_bot_impianto(impianto: dict):      
    """Crea e avvia l'Application per un singolo impianto."""      
    token       = impianto["bot_token"]    
    impianto_id = impianto["id"]       
    nome        = impianto["nome"]     
    if token in _bots:     
        logger.warning(f"Bot {nome} già avviato, skip.")       
        return     
    app = (    
        Application.builder()      
        .token(token)      
        .build()       
    )      
    app.bot_data[IMPIANTO_KEY] = impianto_id       
    for handler in build_handlers():       
        app.add_handler(handler)       
    await app.initialize()     
    await app.start()      
    await app.updater.start_polling(drop_pending_updates=True)     
    _bots[token] = app     
    logger.info(f"✅ Bot avviato: {nome} (impianto_id={impianto_id})")     
async def ferma_bot_impianto(token: str):      
    app = _bots.pop(token, None)       
    if app:    
        await app.updater.stop()       
        await app.stop()       
        await app.shutdown()       
        logger.info(f"Bot fermato: token ...{token[-6:]}")     
async def avvia_tutti():       
    """Avvia un bot per ogni impianto attivo nel DB."""    
    impianti = await db.get_tutti_impianti()       
    if not impianti:       
        logger.warning("Nessun impianto trovato nel database.")    
        return     
    tasks = [avvia_bot_impianto(i) for i in impianti]      
    await asyncio.gather(*tasks)       
    logger.info(f"🚀 {len(impianti)} bot avviati.")    
async def ferma_tutti():       
    tokens = list(_bots.keys())    
    for token in tokens:       
        await ferma_bot_impianto(token)    
    logger.info("Tutti i bot fermati.")    
def get_application(impianto_id: int) -> Application | None:       
    """Restituisce l'Application associata a un impianto (per inviare avvisi)."""      
    for app in _bots.values():     
        if app.bot_data.get(IMPIANTO_KEY) == impianto_id:      
            return app     
    return None    