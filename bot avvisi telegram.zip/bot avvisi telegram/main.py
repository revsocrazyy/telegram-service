
import os       
from dotenv import load_dotenv      
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))        
import asyncio      
import logging      
import signal       
import sys      
import uvicorn      
from db import database as db       
from bot.manager import avvia_tutti, ferma_tutti        
from api.server import app as fastapi_app       
logging.basicConfig(        
    level=logging.INFO,     
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",     
)       
logger = logging.getLogger(__name__)        
async def main():       
    logger.info("Connessione al database…")     
    await db.init_db()      
    logger.info("Database pronto.")     
    await avvia_tutti()     
    host = os.environ.get("API_HOST", "0.0.0.0")        
    port = int(os.environ.get("API_PORT", "8000"))      
    config = uvicorn.Config(        
        app=fastapi_app,        
        host=host,      
        port=port,      
        log_level="info",       
        loop="asyncio",     
    )       
    server = uvicorn.Server(config)     
    if sys.platform != "win32":     
        loop = asyncio.get_running_loop()       
        for sig in (signal.SIGINT, signal.SIGTERM):     
            loop.add_signal_handler(sig, lambda: setattr(server, "should_exit", True))      
    logger.info(f"🌐 API server su http://{host}:{port}  |  Premi CTRL+C per fermare")      
    try:        
        await server.serve()        
    except KeyboardInterrupt:       
        logger.info("CTRL+C ricevuto.")     
    logger.info("Chiusura bot…")        
    await ferma_tutti()     
    await db.close_db()     
    logger.info("👋 Arrivederci.")      
if __name__ == "__main__":      
    asyncio.run(main())     