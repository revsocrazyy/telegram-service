"""  
db/database.py  –  Gestione connessione MySQL con aiomysql   
"""  
import json  
import os    
from typing import Optional, List, Dict  
import aiomysql  
_pool: Optional[aiomysql.Pool] = None    
def _parse_dsn(dsn: str) -> dict:    
    """  
    Converte mysql://user:pass@host:3306/dbname in kwargs per aiomysql.  
    """  
    # Supporta sia mysql:// che mysql+aiomysql://    
    dsn = dsn.replace("mysql+aiomysql://", "mysql://").replace("mysql://", "")   
    user_pass, rest = dsn.split("@", 1)  
    user, password   = user_pass.split(":", 1)   
    host_port, db    = rest.split("/", 1)    
    if ":" in host_port:     
        host, port = host_port.rsplit(":", 1)    
        port = int(port)     
    else:    
        host, port = host_port, 3306     
    return dict(host=host, port=port, user=user, password=password, db=db)   
async def init_db():     
    """Crea il pool di connessioni e applica lo schema."""   
    global _pool     
    kwargs = _parse_dsn(os.environ["DATABASE_URL"])  
    _pool = await aiomysql.create_pool(  
        **kwargs,    
        minsize=2,   
        maxsize=10,  
        autocommit=True,     
        charset="utf8mb4",   
        connect_timeout=10,  
    )    
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")  
    if os.path.exists(schema_path):  
        with open(schema_path) as f:     
            sql = f.read()   
        statements = [s.strip() for s in sql.split(";") if s.strip()]    
        async with _pool.acquire() as conn:  
            async with conn.cursor() as cur:     
                for stmt in statements:  
                    if stmt:     
                        await cur.execute(stmt)  
async def close_db():    
    if _pool:    
        _pool.close()    
        await _pool.wait_closed()    
def get_pool() -> aiomysql.Pool:     
    if _pool is None:    
        raise RuntimeError("Database non inizializzato. Chiama init_db() prima.")    
    return _pool     
async def _fetchrow(sql: str, *args) -> Optional[Dict]:  
    """Esegue una query e restituisce la prima riga come dict."""    
    async with get_pool().acquire() as conn:     
        async with conn.cursor(aiomysql.DictCursor) as cur:  
            await cur.execute(sql, args or None)     
            row = await cur.fetchone()   
    return dict(row) if row else None    
async def _fetchall(sql: str, *args) -> List[Dict]:  
    """Esegue una query e restituisce tutte le righe come lista di dict."""  
    async with get_pool().acquire() as conn:     
        async with conn.cursor(aiomysql.DictCursor) as cur:  
            await cur.execute(sql, args or None)     
            rows = await cur.fetchall()  
    return [dict(r) for r in rows]   
async def _execute(sql: str, *args) -> int:  
    """Esegue una query DML e restituisce lastrowid."""  
    async with get_pool().acquire() as conn:     
        async with conn.cursor() as cur:     
            await cur.execute(sql, args or None)     
            return cur.lastrowid     
async def get_impianto_by_token(token: str) -> Optional[Dict]:   
    return await _fetchrow(  
        "SELECT * FROM impianti WHERE bot_token = %s AND attivo = 1", token  
    )    
async def get_impianto_by_id(impianto_id: int) -> Optional[Dict]:    
    return await _fetchrow(  
        "SELECT * FROM impianti WHERE id = %s", impianto_id  
    )    
async def get_tutti_impianti() -> List[Dict]:    
    return await _fetchall("SELECT * FROM impianti WHERE attivo = 1")    
async def get_utente_by_telefono(impianto_id: int, telefono: str) -> Optional[Dict]:     
    return await _fetchrow(  
        """SELECT * FROM utenti_autorizzati  
           WHERE impianto_id = %s AND telefono = %s""",  
        impianto_id, telefono,   
    )    
async def get_utente_by_telegram_id(impianto_id: int, telegram_id: int) -> Optional[Dict]:   
    return await _fetchrow(  
        """SELECT * FROM utenti_autorizzati  
           WHERE impianto_id = %s AND telegram_id = %s""",   
        impianto_id, telegram_id,    
    )    
async def aggiorna_telegram_id(utente_id: int, telegram_id: int, username: str):     
    await _execute(  
        """UPDATE utenti_autorizzati     
           SET telegram_id = %s, telegram_username = %s  
           WHERE id = %s""",     
        telegram_id, username, utente_id,    
    )    
async def get_utenti_impianto(impianto_id: int) -> List[Dict]:   
    return await _fetchall(  
        "SELECT * FROM utenti_autorizzati WHERE impianto_id = %s",   
        impianto_id,     
    )    
async def is_in_blacklist(telefono: str) -> bool:    
    row = await _fetchrow("SELECT id FROM blacklist WHERE telefono = %s", telefono)  
    return row is not None   
async def aggiungi_a_blacklist(telefono: str, motivo: str, aggiunto_da: str):    
    await _execute(  
        """INSERT INTO blacklist(telefono, motivo, aggiunto_da)  
           VALUES(%s, %s, %s)    
           ON DUPLICATE KEY UPDATE motivo=VALUES(motivo), aggiunto_da=VALUES(aggiunto_da)""",    
        telefono, motivo, aggiunto_da,   
    )    
    await _execute(  
        "UPDATE utenti_autorizzati SET attivo = 1 WHERE telefono = %s", telefono     
    )    
async def rimuovi_da_blacklist(telefono: str):   
    await _execute("DELETE FROM blacklist WHERE telefono = %s", telefono)    
async def get_blacklist() -> List[Dict]:     
    return await _fetchall("SELECT * FROM blacklist ORDER BY created_at DESC")   
async def crea_avviso(   
    impianto_id: int,    
    tipo: str,   
    titolo: str,     
    messaggio: str,  
    severita: int = 1,   
    source: str = None,  
    extra_json: dict = None,     
    foto_file_id: str = None,    
    mittente_telegram_id: int = None,    
) -> int:    
    extra_str = json.dumps(extra_json) if extra_json else None   
    row_id = await _execute(     
        """INSERT INTO avvisi(impianto_id, tipo, titolo, messaggio, severita, source, extra_json, foto_file_id, mittente_telegram_id)    
           VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s)""",    
        impianto_id, tipo, titolo, messaggio, severita, source, extra_str, foto_file_id, mittente_telegram_id,   
    )    
    return row_id    
async def marca_avviso_inviato(avviso_id: int):  
    await _execute(  
        "UPDATE avvisi SET inviato = 1, inviato_at = NOW() WHERE id = %s", avviso_id     
    )    
async def get_avvisi_recenti(impianto_id: int, limite: int = 10) -> List[Dict]:  
    return await _fetchall(  
        """SELECT * FROM avvisi WHERE impianto_id = %s   
           ORDER BY created_at DESC LIMIT %s""",     
        impianto_id, limite,     
    )    
async def log_accesso(   
    impianto_id: Optional[int],  
    telegram_id: Optional[int],  
    telefono: Optional[str],     
    esito: str,  
    dettaglio: str = None,   
):   
    await _execute(  
        """INSERT INTO log_accessi(impianto_id, telegram_id, telefono, esito, dettaglio)     
           VALUES(%s, %s, %s, %s, %s)""",    
        impianto_id, telegram_id, telefono, esito, dettaglio,    
    )    
async def log_comando(impianto_id: int, telegram_id: int, comando: str):     
    await _execute(  
        "INSERT INTO log_comandi(impianto_id, telegram_id, comando) VALUES(%s, %s, %s)",     
        impianto_id, telegram_id, comando,   
    )    