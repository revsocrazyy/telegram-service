SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS impianti (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    nome            VARCHAR(100)    NOT NULL,
    bot_token       VARCHAR(200)    NOT NULL,
    descrizione     TEXT,
    attivo          TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_impianti_nome      (nome),
    UNIQUE KEY uq_impianti_bot_token (bot_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS utenti_autorizzati (
    id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    impianto_id         INT UNSIGNED    NOT NULL,
    telefono            VARCHAR(20)     NOT NULL,
    nome                VARCHAR(200),
    ruolo               VARCHAR(50)     NOT NULL DEFAULT 'operatore',
    telegram_id         BIGINT,
    telegram_username   VARCHAR(100),
    attivo              TINYINT(1)      NOT NULL DEFAULT 1,
    created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_impianto_telefono (impianto_id, telefono),
    KEY idx_telefono    (telefono),
    KEY idx_telegram_id (telegram_id),
    CONSTRAINT fk_utenti_impianto
        FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS blacklist (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    telefono        VARCHAR(20)     NOT NULL,
    motivo          TEXT,
    aggiunto_da     VARCHAR(200),
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_blacklist_telefono (telefono)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS log_accessi (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    impianto_id     INT UNSIGNED,
    telegram_id     BIGINT,
    telefono        VARCHAR(20),
    esito           VARCHAR(20)     NOT NULL,
    dettaglio       TEXT,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_log_accessi_ts (created_at),
    CONSTRAINT fk_log_accessi_impianto
        FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS avvisi (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    impianto_id     INT UNSIGNED    NOT NULL,
    tipo            VARCHAR(50)     NOT NULL,
    titolo          VARCHAR(200)    NOT NULL,
    messaggio       TEXT,
    severita        TINYINT         NOT NULL DEFAULT 1,
    inviato         TINYINT(1)      NOT NULL DEFAULT 0,
    inviato_at      DATETIME,
    source          VARCHAR(100),
    extra_json      JSON,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_avvisi_impianto (impianto_id, inviato),
    CONSTRAINT fk_avvisi_impianto
        FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS log_comandi (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    impianto_id     INT UNSIGNED,
    telegram_id     BIGINT,
    comando         VARCHAR(100),
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_log_comandi_impianto
        FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
