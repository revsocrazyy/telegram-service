import asyncio 
import os  
import aiomysql
DB_URL = os.environ.get("DATABASE_URL", "mysql://root:@localhost:3306/prototipo")  
IMPIANTI_ESEMPIO = [   
    {  
        "nome":       "impiantoAcme",  
        "bot_token":  "8838519641:AAFT-u4cP1F75ezU9-0cXztdEOXBnGa9zNk",
        "descrizione": "Impianto produzione Acme Srl – Linea A",   
    }, 
    {  
        "nome":       "impiantoBeta",  
        "bot_token":  "8911317770:AAHu3IYg-naCazy18cRVWQe3kaUcNvzODOM",
        "descrizione": "Impianto Beta Industries – Reparto 2", 
    }, 
]  
UTENTI_ESEMPIO = [ 
    ("impiantoAcme", "+393331234567", "Mario Rossi",  "admin"),
    ("impiantoAcme", "+393339876543", "Luigi Verdi",  "supervisore"),  
    ("impiantoAcme", "+393335551234", "Anna Bianchi", "operatore"),
    ("impiantoBeta", "+393337778888", "Carlo Neri",   "admin"),
    ("impiantoBeta", "+393331112222", "Sara Gialli",  "operatore"),
]  
def _parse_dsn(dsn: str) -> dict:  
    dsn = dsn.replace("mysql+aiomysql://", "mysql://").replace("mysql://", "") 
    user_pass, rest = dsn.split("@", 1)
    user, password  = user_pass.split(":", 1)  
    host_port, db   = rest.split("/", 1)   
    host, port = (host_port.rsplit(":", 1) if ":" in host_port else (host_port, "3306"))   
    return dict(host=host, port=int(port), user=user, password=password, db=db)
async def setup(): 
    kwargs = _parse_dsn(DB_URL)
    conn = await aiomysql.connect(**kwargs, autocommit=True, charset="utf8mb4")
    cur  = await conn.cursor() 
    schema_path = os.path.join(os.path.dirname(__file__), "../db/schema.sql")  
    with open(schema_path) as f:   
        sql = f.read() 
    for stmt in [s.strip() for s in sql.split(";") if s.strip()]:  
        await cur.execute(stmt)
    print("✅ Schema DB applicato")
    for imp in IMPIANTI_ESEMPIO:   
        await cur.execute( 
            """INSERT INTO impianti(nome, bot_token, descrizione)  
               VALUES(%s, %s, %s)  
               ON DUPLICATE KEY UPDATE descrizione=VALUES(descrizione)""", 
            (imp["nome"], imp["bot_token"], imp["descrizione"]),   
        )  
    print(f"✅ {len(IMPIANTI_ESEMPIO)} impianti inseriti/aggiornati")  
    for nome_imp, telefono, nome, ruolo in UTENTI_ESEMPIO: 
        await cur.execute("SELECT id FROM impianti WHERE nome=%s", (nome_imp,))
        row = await cur.fetchone() 
        if not row:
            print(f"  ⚠️  Impianto '{nome_imp}' non trovato, skip")
            continue   
        imp_id = row[0]
        await cur.execute( 
            """INSERT INTO utenti_autorizzati(impianto_id, telefono, nome, ruolo)  
               VALUES(%s, %s, %s, %s)  
               ON DUPLICATE KEY UPDATE nome=VALUES(nome), ruolo=VALUES(ruolo)""",  
            (imp_id, telefono, nome, ruolo),   
        )  
    print(f"✅ {len(UTENTI_ESEMPIO)} utenti inseriti/aggiornati")  
    await cur.close()  
    conn.close()   
    print("\n🎉 Setup completato!")
if __name__ == "__main__": 
    asyncio.run(setup())   