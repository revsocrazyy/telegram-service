-- ============================================================
--  SCHEMA: Telegram Bot Multi-Impianto  (SQL Server 2016+)
-- ============================================================

-- Impianti
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='impianti' AND xtype='U')
CREATE TABLE impianti (
    id          INT IDENTITY(1,1)   NOT NULL,
    nome        NVARCHAR(100)       NOT NULL,
    bot_token   NVARCHAR(200)       NOT NULL,
    descrizione NVARCHAR(MAX),
    attivo      BIT                 NOT NULL DEFAULT 1,
    created_at  DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_impianti          PRIMARY KEY (id),
    CONSTRAINT uq_impianti_nome     UNIQUE (nome),
    CONSTRAINT uq_impianti_token    UNIQUE (bot_token)
);

-- Utenti autorizzati
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='utenti_autorizzati' AND xtype='U')
CREATE TABLE utenti_autorizzati (
    id                  INT IDENTITY(1,1)   NOT NULL,
    impianto_id         INT                 NOT NULL,
    telefono            NVARCHAR(20)        NOT NULL,
    nome                NVARCHAR(200),
    ruolo               NVARCHAR(50)        NOT NULL DEFAULT 'operatore',
    telegram_id         BIGINT,
    telegram_username   NVARCHAR(100),
    attivo              BIT                 NOT NULL DEFAULT 1,
    created_at          DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_utenti            PRIMARY KEY (id),
    CONSTRAINT uq_impianto_telefono UNIQUE (impianto_id, telefono),
    CONSTRAINT fk_utenti_impianto   FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE CASCADE
);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name='idx_telefono')
    CREATE INDEX idx_telefono    ON utenti_autorizzati(telefono);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name='idx_telegram_id')
    CREATE INDEX idx_telegram_id ON utenti_autorizzati(telegram_id);

-- Blacklist
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='blacklist' AND xtype='U')
CREATE TABLE blacklist (
    id          INT IDENTITY(1,1)   NOT NULL,
    telefono    NVARCHAR(20)        NOT NULL,
    motivo      NVARCHAR(MAX),
    aggiunto_da NVARCHAR(200),
    created_at  DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_blacklist         PRIMARY KEY (id),
    CONSTRAINT uq_blacklist_tel     UNIQUE (telefono)
);

-- Log accessi
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='log_accessi' AND xtype='U')
CREATE TABLE log_accessi (
    id          INT IDENTITY(1,1)   NOT NULL,
    impianto_id INT,
    telegram_id BIGINT,
    telefono    NVARCHAR(20),
    esito       NVARCHAR(20)        NOT NULL,
    dettaglio   NVARCHAR(MAX),
    created_at  DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_log_accessi       PRIMARY KEY (id),
    CONSTRAINT fk_log_impianto      FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE SET NULL
);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name='idx_log_accessi_ts')
    CREATE INDEX idx_log_accessi_ts ON log_accessi(created_at DESC);

-- Avvisi
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='avvisi' AND xtype='U')
CREATE TABLE avvisi (
    id                      INT IDENTITY(1,1)   NOT NULL,
    impianto_id             INT                 NOT NULL,
    tipo                    NVARCHAR(50)        NOT NULL,
    titolo                  NVARCHAR(200)       NOT NULL,
    messaggio               NVARCHAR(MAX),
    severita                TINYINT             NOT NULL DEFAULT 1,
    inviato                 BIT                 NOT NULL DEFAULT 0,
    inviato_at              DATETIME2,
    source                  NVARCHAR(100),
    extra_json              NVARCHAR(MAX),       -- JSON come stringa (SQL Server 2016+ supporta JSON_VALUE)
    foto_file_id            NVARCHAR(200),
    mittente_telegram_id    BIGINT,
    created_at              DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_avvisi            PRIMARY KEY (id),
    CONSTRAINT fk_avvisi_impianto   FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE CASCADE
);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name='idx_avvisi_impianto')
    CREATE INDEX idx_avvisi_impianto ON avvisi(impianto_id, inviato);

-- Log comandi
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='log_comandi' AND xtype='U')
CREATE TABLE log_comandi (
    id          INT IDENTITY(1,1)   NOT NULL,
    impianto_id INT,
    telegram_id BIGINT,
    comando     NVARCHAR(100),
    created_at  DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_log_comandi       PRIMARY KEY (id),
    CONSTRAINT fk_log_comandi_imp   FOREIGN KEY (impianto_id) REFERENCES impianti(id) ON DELETE SET NULL
);
