import requests
from PAYLOAD import PAYLOAD
requests.post(
    "http://localhost:8000/avvisi",
    json=PAYLOAD,
    headers={"X-Api-Key": "API_SECRET"},
)