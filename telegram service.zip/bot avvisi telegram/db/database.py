"""
db/database.py  –  Gestione connessione SQL Server con aioodbc
"""
import json
import os
from typing import Optional, List, Dict
import aioodbc

# ---------------------------------------------------------------------------
# Pool globale
# ---------------------------------------------------------------------------
_pool: Optional[aioodbc.Pool] = None


async def init_db():
    """Crea il pool di connessioni e applica lo schema."""
    global _pool
    dsn = os.environ["DATABASE_URL"]
    _pool = await aioodbc.create_pool(
        dsn=dsn,
        minsize=2,
        maxsize=10,
        autocommit=True,
    )
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    if os.path.exists(schema_path):
        with open(schema_path) as f:
            sql = f.read()
        # SQL Server: esegui statement per statement separati da GO o ;
        statements = [s.strip() for s in sql.split(";") if s.strip()]
        async with _pool.acquire() as conn:
            async with conn.cursor() as cur:
                for stmt in statements:
                    await cur.execute(stmt)


async def close_db():
    if _pool:
        _pool.close()
        await _pool.wait_closed()


def get_pool() -> aioodbc.Pool:
    if _pool is None:
        raise RuntimeError("Database non inizializzato. Chiama init_db() prima.")
    return _pool


async def _fetchrow(sql: str, *args) -> Optional[Dict]:
    async with get_pool().acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(sql, args or ())
            row = await cur.fetchone()
            if not row:
                return None
            cols = [d[0] for d in cur.description]
            return dict(zip(cols, row))


async def _fetchall(sql: str, *args) -> List[Dict]:
    async with get_pool().acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(sql, args or ())
            rows = await cur.fetchall()
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in rows]


async def _execute(sql: str, *args) -> int:
    """Esegue una query DML e restituisce l'ID generato (SCOPE_IDENTITY)."""
    async with get_pool().acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(sql, args or ())
            # Recupera l'ID dell'ultima riga inserita
            await cur.execute("SELECT CAST(SCOPE_IDENTITY() AS INT)")
            row = await cur.fetchone()
            return row[0] if row and row[0] else 0


# ---------------------------------------------------------------------------
# Helpers impianti
# ---------------------------------------------------------------------------

async def get_impianto_by_token(token: str) -> Optional[Dict]:
    return await _fetchrow(
        "SELECT * FROM impianti WHERE bot_token = ? AND attivo = 1", token
    )


async def get_impianto_by_id(impianto_id: int) -> Optional[Dict]:
    return await _fetchrow(
        "SELECT * FROM impianti WHERE id = ?", impianto_id
    )


async def get_tutti_impianti() -> List[Dict]:
    return await _fetchall("SELECT * FROM impianti WHERE attivo = 1")


# ---------------------------------------------------------------------------
# Helpers utenti
# ---------------------------------------------------------------------------

async def get_utente_by_telefono(impianto_id: int, telefono: str) -> Optional[Dict]:
    return await _fetchrow(
        """SELECT * FROM utenti_autorizzati
           WHERE impianto_id = ? AND telefono = ? AND attivo = 1""",
        impianto_id, telefono,
    )


async def get_utente_by_telegram_id(impianto_id: int, telegram_id: int) -> Optional[Dict]:
    return await _fetchrow(
        """SELECT * FROM utenti_autorizzati
           WHERE impianto_id = ? AND telegram_id = ? AND attivo = 1""",
        impianto_id, telegram_id,
    )


async def aggiorna_telegram_id(utente_id: int, telegram_id: int, username: str):
    await _execute(
        """UPDATE utenti_autorizzati
           SET telegram_id = ?, telegram_username = ?
           WHERE id = ?""",
        telegram_id, username, utente_id,
    )


async def get_utenti_impianto(impianto_id: int) -> List[Dict]:
    return await _fetchall(
        "SELECT * FROM utenti_autorizzati WHERE impianto_id = ? AND attivo = 1",
        impianto_id,
    )


# ---------------------------------------------------------------------------
# Helpers blacklist
# ---------------------------------------------------------------------------

async def is_in_blacklist(telefono: str) -> bool:
    row = await _fetchrow("SELECT id FROM blacklist WHERE telefono = ?", telefono)
    return row is not None


async def aggiungi_a_blacklist(telefono: str, motivo: str, aggiunto_da: str):
    # SQL Server: MERGE equivalente a ON DUPLICATE KEY UPDATE
    await _execute(
        """MERGE blacklist AS target
           USING (VALUES (?, ?, ?)) AS source (telefono, motivo, aggiunto_da)
           ON target.telefono = source.telefono
           WHEN MATCHED THEN
               UPDATE SET motivo = source.motivo, aggiunto_da = source.aggiunto_da
           WHEN NOT MATCHED THEN
               INSERT (telefono, motivo, aggiunto_da)
               VALUES (source.telefono, source.motivo, source.aggiunto_da);""",
        telefono, motivo, aggiunto_da,
    )
    await _execute(
        "UPDATE utenti_autorizzati SET attivo = 0 WHERE telefono = ?", telefono
    )


async def rimuovi_da_blacklist(telefono: str):
    await _execute("DELETE FROM blacklist WHERE telefono = ?", telefono)


async def get_blacklist() -> List[Dict]:
    return await _fetchall("SELECT * FROM blacklist ORDER BY created_at DESC")


# ---------------------------------------------------------------------------
# Helpers avvisi
# ---------------------------------------------------------------------------

async def crea_avviso(
    impianto_id: int,
    tipo: str,
    titolo: str,
    messaggio: str,
    severita: int = 1,
    source: str = None,
    extra_json: dict = None,
    foto_file_id: str = None,
    mittente_telegram_id: int = None,
) -> int:
    extra_str = json.dumps(extra_json) if extra_json else None
    return await _execute(
        """INSERT INTO avvisi
               (impianto_id, tipo, titolo, messaggio, severita, source,
                extra_json, foto_file_id, mittente_telegram_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        impianto_id, tipo, titolo, messaggio, severita, source,
        extra_str, foto_file_id, mittente_telegram_id,
    )


async def marca_avviso_inviato(avviso_id: int):
    await _execute(
        "UPDATE avvisi SET inviato = 1, inviato_at = GETUTCDATE() WHERE id = ?",
        avviso_id,
    )


async def get_avvisi_recenti(impianto_id: int, limite: int = 10) -> List[Dict]:
    return await _fetchall(
        """SELECT TOP (?) * FROM avvisi
           WHERE impianto_id = ?
           ORDER BY created_at DESC""",
        limite, impianto_id,
    )


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

async def log_accesso(
    impianto_id: Optional[int],
    telegram_id: Optional[int],
    telefono: Optional[str],
    esito: str,
    dettaglio: str = None,
):
    await _execute(
        """INSERT INTO log_accessi (impianto_id, telegram_id, telefono, esito, dettaglio)
           VALUES (?, ?, ?, ?, ?)""",
        impianto_id, telegram_id, telefono, esito, dettaglio,
    )


async def log_comando(impianto_id: int, telegram_id: int, comando: str):
    await _execute(
        "INSERT INTO log_comandi (impianto_id, telegram_id, comando) VALUES (?, ?, ?)",
        impianto_id, telegram_id, comando,
    )
