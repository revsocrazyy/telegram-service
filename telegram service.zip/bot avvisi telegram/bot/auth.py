import logging   
import re    
from functools import wraps  
from telegram import Update  
from telegram.ext import ContextTypes    
from db import database as db    
logger = logging.getLogger(__name__)     
IMPIANTO_KEY = "impianto_id"     
def normalizza_telefono(numero: str) -> str:     
    """  
    Normalizza un numero di telefono in formato E.164.   
    Rimuove spazi, trattini, parentesi e aggiunge + se mancante.     
    """  
    numero = re.sub(r"[\s\-\(\)]", "", numero)   
    if not numero.startswith("+"):   
        numero = "+" + numero    
    return numero    
def richiedi_autenticazione(func):   
    @wraps(func)     
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):   
        impianto_id: int = context.bot_data.get(IMPIANTO_KEY)    
        user = update.effective_user     
        if not user:     
            return   
        utente = await db.get_utente_by_telegram_id(impianto_id, user.id)    
        if not utente:   
            await update.effective_message.reply_text(   
                "⛔ *Accesso negato.*\n\n"   
                "Non sei ancora autorizzato su questo impianto.\n"   
                "Usa /start e condividi il tuo numero di telefono per autenticarti.",    
                parse_mode="Markdown",   
            )    
            await db.log_accesso(impianto_id, user.id, None, "non_autorizzato", "telegram_id non trovato")  
            return   
        if await db.is_in_blacklist(utente["telefono"]):     
            await update.effective_message.reply_text(   
                "🚫 Il tuo accesso è stato *revocato*.\n"    
                "Contatta l'amministratore di sistema.",     
                parse_mode="Markdown",   
            )    
            await db.log_accesso(impianto_id, user.id, utente["telefono"],   
                                 "blacklist", "accesso bloccato da blacklist")   
            return   
        context.user_data["utente"] = utente     
        return await func(update, context)   
    return wrapper   
async def autentica_da_contatto(     
    update: Update,  
    context: ContextTypes.DEFAULT_TYPE,  
    impianto_id: int,    
) -> bool:   
    contact = update.message.contact     
    if not contact:  
        return False     
    telefono = normalizza_telefono(contact.phone_number)     
    user = update.effective_user     
    if await db.is_in_blacklist(telefono):   
        await update.message.reply_text(     
            "🚫 Il tuo numero è in *blacklist*.\nContatta l'amministratore.",    
            parse_mode="Markdown",   
        )    
        await db.log_accesso(impianto_id, user.id, telefono, "blacklist")    
        return False     
    utente = await db.get_utente_by_telefono(impianto_id, telefono)  
    if not utente:   
        utente = await db.get_utente_by_telefono(impianto_id, telefono.lstrip("+"))  
    if not utente and telefono.startswith("+39"):    
        alternativo = telefono       
        utente = await db.get_utente_by_telefono(impianto_id, alternativo)   
    if not utente:   
        await update.message.reply_text(     
            f"⛔ Il numero `{telefono}` *non è autorizzato* per questo impianto.\n"  
            "Contatta l'amministratore per richiedere l'accesso.",   
            parse_mode="Markdown",   
        )    
        await db.log_accesso(impianto_id, user.id, telefono, "non_autorizzato",  
                             "numero non in whitelist")  
        return False     
    await db.aggiorna_telegram_id(utente["id"], user.id, user.username or "")    
    await db.log_accesso(impianto_id, user.id, telefono, "ok")   
    logger.info(f"Utente autenticato: {telefono} su impianto {impianto_id}")     
    return True  