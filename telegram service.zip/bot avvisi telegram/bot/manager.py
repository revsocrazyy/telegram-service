import asyncio
import logging
from typing import Dict
from telegram.ext import Application
from telegram import Update
import httpx

from bot.handlers import build_handlers
from bot.auth import IMPIANTO_KEY
from db import database as db

logger = logging.getLogger(__name__)

_bots: Dict[str, Application] = {}
_offsets: Dict[str, int] = {}   # offset per ogni bot


async def avvia_bot_impianto(impianto: dict):
    token       = impianto["bot_token"]
    impianto_id = impianto["id"]
    nome        = impianto["nome"]

    if token in _bots:
        logger.warning(f"Bot {nome} già avviato, skip.")
        return

    app = Application.builder().token(token).build()
    app.bot_data[IMPIANTO_KEY] = impianto_id

    for h in build_handlers():
        app.add_handler(h)

    await app.initialize()
    await app.start()

    _bots[token] = app
    _offsets[token] = 0

    logger.info(f"✅ Bot avviato: {nome} (impianto_id={impianto_id})")


async def polling_loop():

    async with httpx.AsyncClient() as client:
        while True:
            for token, app in _bots.items():
                try:
                    offset = _offsets[token]

                    resp = await client.get(
                        f"https://api.telegram.org/bot{token}/getUpdates",
                        params={"timeout": 0, "offset": offset}
                    )
                    data = resp.json()

                    if not data.get("ok"):
                        continue

                    updates = data.get("result", [])

                    for upd in updates:
                        update = Update.de_json(upd, app.bot)
                        await app.process_update(update)
                        _offsets[token] = upd["update_id"] + 1

                except Exception as e:
                    logger.error(f"Errore polling bot {token}: {e}")

            await asyncio.sleep(0.1)


async def avvia_tutti():
    impianti = await db.get_tutti_impianti()
    logger.info(f"Impianti trovati nel DB: {impianti}")

    tasks = [avvia_bot_impianto(i) for i in impianti]
    await asyncio.gather(*tasks)

    logger.info(f"🚀 {len(impianti)} bot avviati.")


async def ferma_tutti():
    for token, app in _bots.items():
        await app.stop()
        await app.shutdown()
    logger.info("🛑 Tutti i bot fermati.")


def get_application(impianto_id: int):
    for app in _bots.values():
        if app.bot_data.get(IMPIANTO_KEY) == impianto_id:
            return app
    return None
