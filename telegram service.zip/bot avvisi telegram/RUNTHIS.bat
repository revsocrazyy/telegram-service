@echo off
echo 🚀 Avvio di tutti i servizi...
start cmd /k "python server_external.py"
start cmd /k "python invia_json.py"
start cmd /k "python main.py"
echo ✅ Tutti i processi sono stati avviati.
