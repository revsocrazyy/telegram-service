PAYLOAD = {
    "impianto_nome": "impiantoAcme",
    "tipo":"allarme",
    "titolo":"test",
    "messaggio":"test",
    "severita":2
}