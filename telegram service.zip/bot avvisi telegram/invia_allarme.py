import requests
from PAYLOAD import PAYLOAD
requests.post(
    "http://localhost:8000/avvisi",
    json=PAYLOAD,
    headers={"X-Api-Key": "8838519641:AAFT-u4cP1F75ezU9-0cXztdEOXBnGa9zNk"},
)