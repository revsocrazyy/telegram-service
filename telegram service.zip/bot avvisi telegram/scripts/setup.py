"""
scripts/setup.py  –  Setup iniziale DB SQL Server
Uso: python scripts/setup.py
"""
import asyncio
import os
import aioodbc

DB_URL = os.environ.get(
    "DATABASE_URL",
    "Driver={ODBC Driver 18 for SQL Server};Server=localhost,1433;Database=prototipo;UID=sa;PWD=BotUser2024!Secure;TrustServerCertificate=yes;"
)

IMPIANTI_ESEMPIO = [
    {"nome": "impiantoAcme",  "bot_token": "8838519641:AAFT-u4cP1F75ezU9-0cXztdEOXBnGa9zNk",  "descrizione": "Impianto Acme Srl – Linea A"},
    {"nome": "impiantoBeta",  "bot_token": "8911317770:AAHu3IYg-naCazy18cRVWQe3kaUcNvzODOM",  "descrizione": "Impianto Beta Industries – Reparto 2"},
]

UTENTI_ESEMPIO = [
    ("impiantoAcme", "+393331234567", "Mario Rossi",  "admin"),
    ("impiantoAcme", "+393339876543", "Luigi Verdi",  "supervisore"),
    ("impiantoAcme", "+393335551234", "Anna Bianchi", "operatore"),
    ("impiantoBeta", "+393337778888", "Carlo Neri",   "admin"),
    ("impiantoBeta", "+393331112222", "Sara Gialli",  "operatore"),
]


async def setup():
    conn = await aioodbc.connect(dsn=DB_URL, autocommit=True)
    cur  = await conn.cursor()

    # Schema
    schema_path = os.path.join(os.path.dirname(__file__), "../db/schema.sql")
    with open(schema_path) as f:
        sql = f.read()
    for stmt in [s.strip() for s in sql.split(";") if s.strip()]:
        await cur.execute(stmt)
    print("✅ Schema DB applicato")

    # Impianti
    for imp in IMPIANTI_ESEMPIO:
        await cur.execute(
            """MERGE impianti AS t
               USING (VALUES (?, ?, ?)) AS s (nome, bot_token, descrizione)
               ON t.nome = s.nome
               WHEN MATCHED THEN UPDATE SET descrizione = s.descrizione
               WHEN NOT MATCHED THEN INSERT (nome, bot_token, descrizione)
                   VALUES (s.nome, s.bot_token, s.descrizione);""",
            (imp["nome"], imp["bot_token"], imp["descrizione"]),
        )
    print(f"✅ {len(IMPIANTI_ESEMPIO)} impianti inseriti/aggiornati")

    # Utenti
    for nome_imp, telefono, nome, ruolo in UTENTI_ESEMPIO:
        await cur.execute("SELECT id FROM impianti WHERE nome = ?", (nome_imp,))
        row = await cur.fetchone()
        if not row:
            print(f"  ⚠️  Impianto '{nome_imp}' non trovato, skip")
            continue
        imp_id = row[0]
        await cur.execute(
            """MERGE utenti_autorizzati AS t
               USING (VALUES (?, ?, ?, ?)) AS s (impianto_id, telefono, nome, ruolo)
               ON t.impianto_id = s.impianto_id AND t.telefono = s.telefono
               WHEN MATCHED THEN UPDATE SET nome = s.nome, ruolo = s.ruolo
               WHEN NOT MATCHED THEN INSERT (impianto_id, telefono, nome, ruolo)
                   VALUES (s.impianto_id, s.telefono, s.nome, s.ruolo);""",
            (imp_id, telefono, nome, ruolo),
        )
    print(f"✅ {len(UTENTI_ESEMPIO)} utenti inseriti/aggiornati")

    await cur.close()
    await conn.close()
    print("\n🎉 Setup completato!")
    print("\nProssimi passi:")
    print("  1. Aggiorna i bot_token nella tabella impianti con i token reali di @BotFather")
    print("  2. Imposta DATABASE_URL e API_SECRET nel file .env")
    print("  3. Lancia: python main.py")


if __name__ == "__main__":
    asyncio.run(setup())
