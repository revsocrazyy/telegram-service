import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Risposta(BaseModel):
    nome: str
    risposta: str

@app.post("/risposte")
async def ricevi_risposta(payload: Risposta):
    print("📩 RISPOSTA ARRIVATA:")
    print(f"👤 Nome: {payload.nome}")
    print(f"💬 Risposta: {payload.risposta}")
    print("-" * 40)
    return {"ok": True}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5050)
