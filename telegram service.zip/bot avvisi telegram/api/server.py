"""
api/server.py  –  API HTTP compatibile SQL Server (aioodbc)
"""
import logging
import os
import re
from datetime import datetime, timezone
from typing import Optional
 
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from telegram import Bot
 
from db import database as db
from bot.manager import get_application
 
logger = logging.getLogger(__name__)
 
app = FastAPI(
    title="Telegram Bot – API",
    description="Gestione avvisi, blacklist e registrazione utenti",
    version="1.0.0",
)
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
 
API_SECRET = os.environ.get("API_SECRET", "cambia_questa_chiave")
 
SEVERITA_EMOJI = {1: "ℹ️", 2: "⚠️", 3: "🔴", 4: "🆘"}
SEVERITA_LABEL  = {1: "Info", 2: "Warning", 3: "Errore", 4: "CRITICO"}
 
# Risposte in memoria
RISPOSTE_RICEVUTE = []
 
 
# ── Modelli ──────────────────────────────────────────────────────────────────
 
class AvvisoRequest(BaseModel):
    impianto_nome: str          = Field(...)
    tipo:          str          = Field(...)
    titolo:        str          = Field(...)
    messaggio:     Optional[str] = None
    severita:      int          = Field(1, ge=1, le=4)
    source:        Optional[str] = None
    extra:         Optional[dict] = None
 
class BlacklistRequest(BaseModel):
    telefono:    str
    motivo:      Optional[str] = "Rimosso via API"
    aggiunto_da: Optional[str] = "sistema"
 
class RegistrazioneRequest(BaseModel):
    impianto_nome: str
    telefono:      str
    nome:          str
    ruolo:         str = "operatore"
 
class RispostaOk(BaseModel):
    ok:        bool = True
    messaggio: str
    avviso_id: Optional[int] = None
 
class RegistrazioneRisposta(BaseModel):
    ok:           bool = True
    messaggio:    str
    utente_id:    int
    bot_username: Optional[str] = None
 
 
# ── Auth ─────────────────────────────────────────────────────────────────────
 
def verifica_api_key(x_api_key: str = Header(...)):
    if x_api_key != API_SECRET:
        raise HTTPException(status_code=401, detail="API key non valida")
    return x_api_key
 
 
# ── /impianti ────────────────────────────────────────────────────────────────
 
@app.get("/impianti", tags=["Impianti"])
async def lista_impianti(_: str = Depends(verifica_api_key)):
    impianti = await db.get_tutti_impianti()
    return [{"nome": i["nome"], "descrizione": i["descrizione"]} for i in impianti]
 
 
# ── /registra ────────────────────────────────────────────────────────────────
 
@app.post("/registra", response_model=RegistrazioneRisposta, tags=["Utenti"])
async def registra_utente(payload: RegistrazioneRequest, _: str = Depends(verifica_api_key)):
    telefono = re.sub(r"[\s\-\(\)]", "", payload.telefono)
    if not telefono.startswith("+"):
        telefono = "+" + telefono
 
    # Cerca impianto
    imp = await db._fetchrow(
        "SELECT id, bot_token FROM impianti WHERE nome = ? AND attivo = 1",
        payload.impianto_nome,
    )
    if not imp:
        raise HTTPException(status_code=404, detail=f"Impianto '{payload.impianto_nome}' non trovato")
 
    if await db.is_in_blacklist(telefono):
        raise HTTPException(status_code=403, detail="Numero in blacklist")
 
    if payload.ruolo not in ("operatore", "supervisore", "admin"):
        raise HTTPException(status_code=400, detail="Ruolo non valido")
 
    # MERGE (upsert SQL Server)
    utente_id = await db._execute(
        """MERGE utenti_autorizzati AS t
           USING (VALUES (?, ?, ?, ?)) AS s (impianto_id, telefono, nome, ruolo)
           ON t.impianto_id = s.impianto_id AND t.telefono = s.telefono
           WHEN MATCHED THEN
               UPDATE SET nome = s.nome, ruolo = s.ruolo, attivo = 1
           WHEN NOT MATCHED THEN
               INSERT (impianto_id, telefono, nome, ruolo)
               VALUES (s.impianto_id, s.telefono, s.nome, s.ruolo);""",
        imp["id"], telefono, payload.nome.strip(), payload.ruolo,
    )
 
    # Username bot per redirect
    bot_username = None
    try:
        me = await Bot(token=imp["bot_token"]).get_me()
        bot_username = me.username
    except Exception as e:
        logger.warning(f"Impossibile recuperare username bot: {e}")
 
    logger.info(f"Utente registrato: {telefono} su {payload.impianto_nome} (ruolo={payload.ruolo})")
    return RegistrazioneRisposta(
        messaggio    = f"Utente {payload.nome} registrato su {payload.impianto_nome}",
        utente_id    = utente_id or 0,
        bot_username = bot_username,
    )
 
 
# ── /avvisi ──────────────────────────────────────────────────────────────────
 
@app.post("/avvisi", response_model=RispostaOk, tags=["Avvisi"])
async def invia_avviso(payload: AvvisoRequest, _: str = Depends(verifica_api_key)):
    imp = await db._fetchrow(
        "SELECT * FROM impianti WHERE nome = ? AND attivo = 1",
        payload.impianto_nome,
    )
    if not imp:
        raise HTTPException(status_code=404, detail=f"Impianto '{payload.impianto_nome}' non trovato")
 
    avviso_id = await db.crea_avviso(
        impianto_id = imp["id"],
        tipo        = payload.tipo,
        titolo      = payload.titolo,
        messaggio   = payload.messaggio or "",
        severita    = payload.severita,
        source      = payload.source,
        extra_json  = payload.extra,
    )
 
    emoji  = SEVERITA_EMOJI.get(payload.severita, "ℹ️")
    label  = SEVERITA_LABEL.get(payload.severita, "?")
    tg_msg = f"{emoji} *{label.upper()} – {payload.titolo}*\n🏭 _{imp['nome']}_\n"
    if payload.source:
        tg_msg += f"📡 `{payload.source}`\n"
    if payload.messaggio:
        tg_msg += f"\n{payload.messaggio}\n"
 
    utenti  = await db.get_utenti_impianto(imp["id"])
    app_bot = get_application(imp["id"])
    inviati = 0
 
    if app_bot:
        for u in utenti:
            if u["telegram_id"]:
                try:
                    await app_bot.bot.send_message(
                        chat_id    = u["telegram_id"],
                        text       = tg_msg,
                        parse_mode = "Markdown",
                    )
                    app_bot.bot_data.setdefault("attesa_risposta", {})[u["telegram_id"]] = {
                        "avviso_id":   avviso_id,
                        "titolo":      payload.titolo,
                        "mittente_id": None,
                    }
                    inviati += 1
                except Exception as e:
                    logger.error(f"Errore invio a {u['telegram_id']}: {e}")
 
    await db.marca_avviso_inviato(avviso_id)
    return RispostaOk(messaggio=f"Avviso inviato a {inviati} utenti", avviso_id=avviso_id)
 
 
# ── /blacklist ───────────────────────────────────────────────────────────────
 
@app.post("/blacklist", response_model=RispostaOk, tags=["Blacklist"])
async def aggiungi_blacklist(payload: BlacklistRequest, _: str = Depends(verifica_api_key)):
    await db.aggiungi_a_blacklist(payload.telefono, payload.motivo, payload.aggiunto_da)
    return RispostaOk(messaggio=f"Numero {payload.telefono} aggiunto alla blacklist")
 
@app.delete("/blacklist/{telefono}", response_model=RispostaOk, tags=["Blacklist"])
async def rimuovi_blacklist(telefono: str, _: str = Depends(verifica_api_key)):
    await db.rimuovi_da_blacklist(telefono)
    return RispostaOk(messaggio=f"Numero {telefono} rimosso dalla blacklist")
 
@app.get("/blacklist", tags=["Blacklist"])
async def get_blacklist(_: str = Depends(verifica_api_key)):
    return await db.get_blacklist()
 
 
# ── /utenti ──────────────────────────────────────────────────────────────────
 
@app.get("/utenti", tags=["Utenti"])
async def lista_utenti(impianto: Optional[str] = None, _: str = Depends(verifica_api_key)):
    if impianto:
        rows = await db._fetchall(
            """SELECT u.*, i.nome AS impianto_nome
               FROM utenti_autorizzati u
               JOIN impianti i ON i.id = u.impianto_id
               WHERE i.nome = ? AND u.attivo = 1
               ORDER BY u.created_at DESC""",
            impianto,
        )
    else:
        rows = await db._fetchall(
            """SELECT u.*, i.nome AS impianto_nome
               FROM utenti_autorizzati u
               JOIN impianti i ON i.id = u.impianto_id
               WHERE u.attivo = 1
               ORDER BY u.created_at DESC""",
        )
    return rows
 
 
# ── /risposte ────────────────────────────────────────────────────────────────
 
@app.post("/risposte", tags=["Risposte"])
async def ricevi_risposta(payload: dict):
    nome     = payload.get("nome")
    risposta = payload.get("risposta")
    if not nome or not risposta:
        raise HTTPException(status_code=400, detail="Payload incompleto: servono 'nome' e 'risposta'")
    RISPOSTE_RICEVUTE.append({
        "nome":      nome,
        "risposta":  risposta,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })
    logger.info(f"Risposta ricevuta da {nome}: {risposta}")
    return {"ok": True}
 
@app.get("/risposte", tags=["Risposte"])
async def mostra_risposte():
    return {"totale": len(RISPOSTE_RICEVUTE), "risposte": RISPOSTE_RICEVUTE}
 
 
# ── /health ──────────────────────────────────────────────────────────────────
 
@app.get("/health", tags=["Sistema"])
async def health():
    return {"status": "ok"}