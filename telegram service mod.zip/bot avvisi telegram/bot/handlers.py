import logging
from datetime import datetime
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    ContextTypes, CommandHandler, MessageHandler,
    ConversationHandler, filters
)
from bot.auth import richiedi_autenticazione, autentica_da_contatto, IMPIANTO_KEY
from db import database as db
 
logger = logging.getLogger(__name__)
awaiting_response = {}
ATTESA_CONTATTO   = 1  
 
ALLARME_TITOLO    = 10
ALLARME_MESSAGGIO = 11
ALLARME_FOTO      = 12
ALLARME_SEVERITA  = 13
ALLARME_CONFERMA  = 14
 
SEVERITA_EMOJI = {1: "ℹ️", 2: "⚠️", 3: "🔴", 4: "🆘"}
SEVERITA_LABEL  = {1: "Info", 2: "Warning", 3: "Errore", 4: "CRITICO"}
 
SEVERITA_DA_TESTO = {
    "ℹ️ info":    1,
    "⚠️ warning": 2,
    "🔴 errore":  3,
    "🆘 critico": 4,
}

def kb_severita():
    return ReplyKeyboardMarkup(
        [["ℹ️ Info", "⚠️ Warning"], ["🔴 Errore", "🆘 CRITICO"]],
        one_time_keyboard=True, resize_keyboard=True,
    )
 
def kb_conferma():
    return ReplyKeyboardMarkup(
        [["✅ Invia", "❌ Annulla"]],
        one_time_keyboard=True, resize_keyboard=True,
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    impianto_id = context.bot_data.get(IMPIANTO_KEY)
    impianto    = await db.get_impianto_by_id(impianto_id)
    user        = update.effective_user
 
    utente = await db.get_utente_by_telegram_id(impianto_id, user.id)
    if utente:
        await update.message.reply_text(
            f"👋 Bentornato, *{utente['nome'] or user.first_name}*!\n\n"
            f"🏭 Impianto: *{impianto['nome']}*\n"
            f"👤 Ruolo: _{utente['ruolo']}_\n\n"
            "Usa /help per vedere i comandi disponibili.",
            parse_mode="Markdown",
            reply_markup=ReplyKeyboardRemove(),
        )
        return ConversationHandler.END
 
    kb = ReplyKeyboardMarkup(
        [[KeyboardButton("📱 Condividi il mio numero", request_contact=True)]],
        one_time_keyboard=True, resize_keyboard=True,
    )
    await update.message.reply_text(
        f"👋 Benvenuto nel bot dell'impianto *{impianto['nome']}*.\n\n"
        "Per accedere devi verificare il tuo numero di telefono.\n"
        "Premi il pulsante qui sotto per condividerlo:",
        parse_mode="Markdown",
        reply_markup=kb,
    )
    return ATTESA_CONTATTO
 
 
async def ricevi_contatto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    impianto_id = context.bot_data.get(IMPIANTO_KEY)
    impianto    = await db.get_impianto_by_id(impianto_id)
 
    autenticato = await autentica_da_contatto(update, context, impianto_id)
    if autenticato:
        utente = await db.get_utente_by_telegram_id(impianto_id, update.effective_user.id)
        await update.message.reply_text(
            f"✅ *Accesso autorizzato!*\n\n"
            f"🏭 Impianto: *{impianto['nome']}*\n"
            f"👤 {utente['nome']} – _{utente['ruolo']}_\n\n"
            "Usa /help per vedere i comandi disponibili.",
            parse_mode="Markdown",
            reply_markup=ReplyKeyboardRemove(),
        )
    return ConversationHandler.END
 
 
async def annulla_generico(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Operazione annullata.", reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END

@richiedi_autenticazione
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ruolo = context.user_data["utente"].get("ruolo", "operatore")
    testo = (
        "📋 *Comandi disponibili*\n\n"
        "*/start* – Autenticati o mostra il benvenuto\n"
        "*/help* – Mostra questo messaggio\n"
        "*/status* – Stato attuale dell'impianto\n"
        "*/allarmi* – Ultimi 10 allarmi/avvisi\n"
        "*/io* – Info sul tuo account\n"
    )
    if ruolo in ("supervisore", "admin"):
        testo += (
            "\n👤 *Comandi Supervisore/Admin*\n"
            "*/utenti* – Lista utenti autorizzati\n"
            "*/invia_allarme* – Crea e invia un allarme a tutti gli utenti\n"
        )
    if ruolo == "admin":
        testo += (
            "\n🔧 *Comandi Admin*\n"
            "*/blacklist* – Mostra la blacklist\n"
            "*/blocca <telefono> <motivo>* – Aggiungi alla blacklist\n"
            "*/sblocca <telefono>* – Rimuovi dalla blacklist\n"
        )
    await update.message.reply_text(testo, parse_mode="Markdown")
    await db.log_comando(context.bot_data[IMPIANTO_KEY], update.effective_user.id, "/help")

@richiedi_autenticazione
async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    impianto_id = context.bot_data[IMPIANTO_KEY]
    impianto    = await db.get_impianto_by_id(impianto_id)
    avvisi      = await db.get_avvisi_recenti(impianto_id, limite=5)
 
    critici  = sum(1 for a in avvisi if a["severita"] >= 3)
    warnings = sum(1 for a in avvisi if a["severita"] == 2)
    stato_emoji = "🟢" if critici == 0 and warnings == 0 else ("🔴" if critici > 0 else "🟡")
 
    testo = (
        f"🏭 *{impianto['nome']}*\n"
        f"Stato: {stato_emoji}\n"
        f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M')}\n\n"
        f"  🔴 Critici/Errori: {critici}\n"
        f"  ⚠️  Warning: {warnings}\n\n"
    )
    if avvisi:
        testo += "🔔 *Avvisi recenti:*\n"
        for a in avvisi[:3]:
            emoji = SEVERITA_EMOJI.get(a["severita"], "ℹ️")
            ts    = a["created_at"].strftime("%d/%m %H:%M")
            testo += f"{emoji} `[{ts}]` {a['titolo']}\n"
    else:
        testo += "✅ Nessun avviso recente."
 
    await update.message.reply_text(testo, parse_mode="Markdown")
    await db.log_comando(impianto_id, update.effective_user.id, "/status")

@richiedi_autenticazione
async def allarmi_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    impianto_id = context.bot_data[IMPIANTO_KEY]
    avvisi      = await db.get_avvisi_recenti(impianto_id, limite=10)
 
    if not avvisi:
        await update.message.reply_text("✅ Nessun allarme recente.")
        return
 
    testo = "🔔 *Ultimi 10 avvisi*\n\n"
    for a in avvisi:
        emoji = SEVERITA_EMOJI.get(a["severita"], "ℹ️")
        label = SEVERITA_LABEL.get(a["severita"], "?")
        ts    = a["created_at"].strftime("%d/%m/%Y %H:%M")
        foto  = " 📷" if a.get("foto_file_id") else ""
        testo += (
            f"{emoji} *{a['titolo']}*{foto}\n"
            f"   {label} | 🕐 {ts}"
        )
        if a.get("source"):
            testo += f" | _{a['source']}_"
        testo += "\n\n"
 
    await update.message.reply_text(testo, parse_mode="Markdown")
    await db.log_comando(impianto_id, update.effective_user.id, "/allarmi")
 
@richiedi_autenticazione
async def io_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    utente = context.user_data["utente"]
    await update.message.reply_text(
        "👤 *Il tuo account*\n\n"
        f"Nome: {utente['nome'] or 'N/D'}\n"
        f"Telefono: `{utente['telefono']}`\n"
        f"Ruolo: _{utente['ruolo']}_\n"
        f"Attivo dal: {utente['created_at'].strftime('%d/%m/%Y')}\n",
        parse_mode="Markdown",
    )

@richiedi_autenticazione
async def utenti_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data["utente"]["ruolo"] not in ("supervisore", "admin"):
        await update.message.reply_text("⛔ Non hai i permessi per questo comando.")
        return
 
    impianto_id = context.bot_data[IMPIANTO_KEY]
    utenti      = await db.get_utenti_impianto(impianto_id)
 
    testo = f"👥 *Utenti autorizzati* ({len(utenti)})\n\n"
    for u in utenti:
        online = "🟢" if u["telegram_id"] else "⚫"
        testo += f"{online} {u['nome'] or 'N/D'} – `{u['telefono']}` _{u['ruolo']}_\n"
 
    await update.message.reply_text(testo, parse_mode="Markdown")
    await db.log_comando(impianto_id, update.effective_user.id, "/utenti")

@richiedi_autenticazione
async def rispondi_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    utente = context.user_data["utente"]

    if utente["ruolo"] != "admin":
        await update.message.reply_text("⛔ Comando riservato agli admin.")
        return

    chat_id = update.effective_chat.id
    awaiting_response[chat_id] = True

    await update.message.reply_text("Perfetto, mandami ora la tua risposta.")



@richiedi_autenticazione
async def blacklist_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data["utente"]["ruolo"] != "admin":
        await update.message.reply_text("⛔ Comando riservato agli admin.")
        return
 
    lista = await db.get_blacklist()
    if not lista:
        await update.message.reply_text("✅ Blacklist vuota.")
        return
 
    testo = f"🚫 *Blacklist* ({len(lista)} numeri)\n\n"
    for b in lista:
        ts = b["created_at"].strftime("%d/%m/%Y")
        testo += f"• `{b['telefono']}` – {b['motivo'] or 'N/D'} _{ts}_\n"
 
    await update.message.reply_text(testo, parse_mode="Markdown")

@richiedi_autenticazione
async def blocca_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data["utente"]["ruolo"] != "admin":
        await update.message.reply_text("⛔ Comando riservato agli admin.")
        return
 
    args = context.args
    if not args:
        await update.message.reply_text(
            "Uso: `/blocca +39XXXXXXXXXX motivo`", parse_mode="Markdown"
        )
        return
 
    telefono    = args[0]
    motivo      = " ".join(args[1:]) if len(args) > 1 else "Non specificato"
    aggiunto_da = context.user_data["utente"].get("nome") or str(update.effective_user.id)
 
    await db.aggiungi_a_blacklist(telefono, motivo, aggiunto_da)
    await update.message.reply_text(
        f"🚫 `{telefono}` aggiunto alla blacklist.\nMotivo: _{motivo}_",
        parse_mode="Markdown",
    )
 

@richiedi_autenticazione
async def sblocca_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data["utente"]["ruolo"] != "admin":
        await update.message.reply_text("⛔ Comando riservato agli admin.")
        return
 
    args = context.args
    if not args:
        await update.message.reply_text("Uso: `/sblocca +39XXXXXXXXXX`", parse_mode="Markdown")
        return
 
    await db.rimuovi_da_blacklist(args[0])
    await update.message.reply_text(f"✅ `{args[0]}` rimosso dalla blacklist.", parse_mode="Markdown")
 
@richiedi_autenticazione
async def invia_allarme_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data["utente"]["ruolo"] not in ("supervisore", "admin"):
        await update.message.reply_text("⛔ Comando riservato a supervisori e admin.")
        return ConversationHandler.END
 
    context.user_data["nuovo_allarme"] = {}
    await update.message.reply_text(
        "🔔 *Nuovo allarme* — Passo 1/4\n\n"
        "✏️ Inserisci il *titolo* dell'allarme:\n\n"
        "_Invia /annulla per annullare in qualsiasi momento._",
        parse_mode="Markdown",
        reply_markup=ReplyKeyboardRemove(),
    )
    return ALLARME_TITOLO
 
 
async def allarme_step_titolo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    titolo = update.message.text.strip()
    if len(titolo) < 3:
        await update.message.reply_text("❗ Titolo troppo corto. Riprova:")
        return ALLARME_TITOLO
 
    context.user_data["nuovo_allarme"]["titolo"] = titolo
    await update.message.reply_text(
        "📝 *Passo 2/4*\n\n"
        "Inserisci il *messaggio* dettagliato\n"
        "_(oppure manda `-` per saltare)_:",
        parse_mode="Markdown",
    )
    return ALLARME_MESSAGGIO
 
 
async def allarme_step_messaggio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    testo = update.message.text.strip()
    context.user_data["nuovo_allarme"]["messaggio"] = "" if testo == "-" else testo
 
    await update.message.reply_text(
        "📷 *Passo 3/4*\n\n"
        "Invia una *foto* allegata all'allarme\n"
        "_(oppure manda `-` per saltare)_:",
        parse_mode="Markdown",
    )
    return ALLARME_FOTO
 
 
async def allarme_step_foto_testo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gestisce il '-' per saltare la foto."""
    if update.message.text.strip() == "-":
        context.user_data["nuovo_allarme"]["foto_file_id"] = None
        await update.message.reply_text(
            "🚦 *Passo 4/4*\n\nScegli la *severità*:",
            parse_mode="Markdown",
            reply_markup=kb_severita(),
        )
        return ALLARME_SEVERITA
 
    await update.message.reply_text(
        "❗ Invia una *foto* oppure manda `-` per saltare.",
        parse_mode="Markdown",
    )
    return ALLARME_FOTO
 
 
async def allarme_step_foto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gestisce la ricezione della foto."""
    foto = update.message.photo[-1]
    context.user_data["nuovo_allarme"]["foto_file_id"] = foto.file_id
 
    await update.message.reply_text(
        "✅ Foto ricevuta!\n\n"
        "🚦 *Passo 4/4*\n\nScegli la *severità*:",
        parse_mode="Markdown",
        reply_markup=kb_severita(),
    )
    return ALLARME_SEVERITA
 
 
async def allarme_step_severita(update: Update, context: ContextTypes.DEFAULT_TYPE):
    testo    = update.message.text.strip().lower()
    severita = SEVERITA_DA_TESTO.get(testo)
 
    if not severita:
        await update.message.reply_text(
            "❗ Scegli una delle opzioni dal menu.",
            reply_markup=kb_severita(),
        )
        return ALLARME_SEVERITA
 
    context.user_data["nuovo_allarme"]["severita"] = severita
    dati  = context.user_data["nuovo_allarme"]
    emoji = SEVERITA_EMOJI[severita]
    label = SEVERITA_LABEL[severita]
 
    riepilogo = (
        f"📋 *Riepilogo allarme*\n\n"
        f"{emoji} Severità: *{label}*\n"
        f"📌 Titolo: *{dati['titolo']}*\n"
    )
    if dati.get("messaggio"):
        riepilogo += f"📝 Messaggio: {dati['messaggio']}\n"
    riepilogo += f"📷 Foto: {'allegata ✅' if dati.get('foto_file_id') else 'nessuna'}\n"
    riepilogo += "\n*Confermi l'invio a tutti gli utenti dell'impianto?*"
 
    await update.message.reply_text(
        riepilogo,
        parse_mode="Markdown",
        reply_markup=kb_conferma(),
    )
    return ALLARME_CONFERMA
 
 
async def allarme_step_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    risposta = update.message.text.strip()
 
    if risposta == "❌ Annulla":
        context.user_data.pop("nuovo_allarme", None)
        await update.message.reply_text("❌ Allarme annullato.", reply_markup=ReplyKeyboardRemove())
        return ConversationHandler.END
 
    if risposta != "✅ Invia":
        await update.message.reply_text(
            "❗ Usa i pulsanti per confermare o annullare.",
            reply_markup=kb_conferma(),
        )
        return ALLARME_CONFERMA
 
    impianto_id = context.bot_data[IMPIANTO_KEY]
    dati        = context.user_data["nuovo_allarme"]
    mittente    = context.user_data["utente"]
 
    avviso_id = await db.crea_avviso(
        impianto_id          = impianto_id,
        tipo                 = "allarme",
        titolo               = dati["titolo"],
        messaggio            = dati.get("messaggio", ""),
        severita             = dati["severita"],
        source               = f"Bot – {mittente['nome'] or mittente['telefono']}",
        foto_file_id         = dati.get("foto_file_id"),
        mittente_telegram_id = mittente["telegram_id"],
    )
 
    emoji    = SEVERITA_EMOJI[dati["severita"]]
    label    = SEVERITA_LABEL[dati["severita"]]
    impianto = await db.get_impianto_by_id(impianto_id)
    caption  = (
        f"{emoji} *{label.upper()} – {dati['titolo']}*\n"
        f"🏭 _{impianto['nome']}_\n"
        f"👤 _{mittente['nome'] or mittente['telefono']}_\n"
    )
    if dati.get("messaggio"):
        caption += f"\n{dati['messaggio']}"
 
    foto_file_id = dati.get("foto_file_id")
 
    utenti      = await db.get_utenti_impianto(impianto_id)
    bot         = context.bot
    inviati     = 0
    saltati     = 0
    mittente_id = mittente["telegram_id"]
 
    for u in utenti:
        if not u["telegram_id"] or u["telegram_id"] == mittente_id:
            if not u["telegram_id"]:
                saltati += 1
            continue
        try:
            if foto_file_id:
                await bot.send_photo(
                    chat_id   = u["telegram_id"],
                    photo     = foto_file_id,
                    caption   = caption,
                    parse_mode= "Markdown",
                )
            else:
                await bot.send_message(
                    chat_id    = u["telegram_id"],
                    text       = caption,
                    parse_mode = "Markdown",
                )
            contesto = context.bot_data.setdefault("attesa_risposta", {})
            contesto[u["telegram_id"]] = {
                "avviso_id":   avviso_id,
                "titolo":      dati["titolo"],
                "mittente_id": mittente_id,
            }
            inviati += 1
        except Exception as e:
            logger.error(f"Errore invio a {u['telegram_id']}: {e}")
            saltati += 1
 
    await db.marca_avviso_inviato(avviso_id)
    context.user_data.pop("nuovo_allarme", None)
 
    await update.message.reply_text(
        f"✅ *Allarme inviato!*\n\n"
        f"📨 Consegnato a *{inviati}* utenti\n"
        f"⚫ Non ancora registrati: {saltati}\n"
        f"🆔 ID avviso: `{avviso_id}`",
        parse_mode="Markdown",
        reply_markup=ReplyKeyboardRemove(),
    )
    return ConversationHandler.END
 
 
async def allarme_annulla(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("nuovo_allarme", None)
    await update.message.reply_text("❌ Allarme annullato.", reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END


  
@richiedi_autenticazione
async def messaggio_sconosciuto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    utente      = context.user_data["utente"]
    telegram_id = update.effective_user.id
    attesa      = context.bot_data.get("attesa_risposta", {})

    # ---------------------------------------------------------
    # 1) RISPOSTA AL COMANDO /rispondi (solo admin)
    # ---------------------------------------------------------
    if awaiting_response.get(telegram_id):

        if utente["ruolo"] != "admin":
            awaiting_response[telegram_id] = False
            await update.message.reply_text("⛔ Solo gli admin possono inviare risposte.")
            return

        awaiting_response[telegram_id] = False

        risposta_testo = update.message.text.strip()
        nome_utente    = utente["nome"]

        # 🔥 Salvataggio locale completo
        import os, json
        os.makedirs("risposte_utenti", exist_ok=True)

        payload_completo = {
            "utente":    nome_utente,
            "telefono":  utente["telefono"],
            "ruolo":     utente["ruolo"],
            "risposta":  risposta_testo,
            "timestamp": datetime.utcnow().isoformat(),
        }

        filename = f"risposte_utenti/{telegram_id}_{int(datetime.utcnow().timestamp())}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(payload_completo, f, indent=2, ensure_ascii=False)

        # 🔥 Payload minimale per server_external.py
        payload_minimale = {
            "nome": nome_utente,
            "risposta": risposta_testo
        }

        # 🔥 INVIO AL SERVER ESTERNO
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                await client.post(
                    "http://localhost:5050/risposte",
                    json=payload_minimale,
                    timeout=10
                )
            await update.message.reply_text("✅ Risposta inviata al server esterno.")
        except Exception as e:
            logger.error(f"Errore invio server esterno: {e}")
            await update.message.reply_text("⚠️ Risposta salvata ma NON inviata (server esterno offline).")

        return

    # ---------------------------------------------------------
    # 2) RISPOSTA A UN ALLARME (logica già esistente)
    # ---------------------------------------------------------
    if telegram_id not in attesa:
        await update.message.reply_text("❓ Usa /help per i comandi disponibili.")
        return

    import json, os
    from datetime import timezone

    info   = attesa.pop(telegram_id)
    testo  = update.message.text.strip()
    ts     = datetime.now(timezone.utc)
    ts_str = ts.strftime("%Y%m%d_%H%M%S")

    os.makedirs("risposte_utenti", exist_ok=True)
    payload = {
        "utente":    utente["nome"],
        "telefono":  utente["telefono"],
        "risposta":  testo,
        "timestamp": ts.isoformat(),
        "avviso_id": info["avviso_id"],
        "allarme":   info["titolo"],
    }

    nome_file = f"risposte_utenti/{(utente['nome'] or 'utente').replace(' ','_')}_{ts_str}.json"
    with open(nome_file, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    try:
        await context.bot.send_message(
            chat_id    = info["mittente_id"],
            text       = f"💬 *{utente['nome']}* ha risposto all'allarme «{info['titolo']}»:\n\n_{testo}_",
            parse_mode = "Markdown",
        )
    except Exception as e:
        logger.error(f"Errore notifica mittente: {e}")

    await update.message.reply_text("✅ Risposta registrata.")

def build_handlers():
    conv_start = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ATTESA_CONTATTO: [
                MessageHandler(filters.CONTACT, ricevi_contatto),
                CommandHandler("annulla", annulla_generico),
            ],
        },
        fallbacks=[CommandHandler("annulla", annulla_generico)],
    )
 
    conv_allarme = ConversationHandler(
        entry_points=[CommandHandler("invia_allarme", invia_allarme_start)],
        states={
            ALLARME_TITOLO: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, allarme_step_titolo),
            ],
            ALLARME_MESSAGGIO: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, allarme_step_messaggio),
            ],
            ALLARME_FOTO: [
                MessageHandler(filters.PHOTO, allarme_step_foto),
                MessageHandler(filters.TEXT & ~filters.COMMAND, allarme_step_foto_testo),
            ],
            ALLARME_SEVERITA: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, allarme_step_severita),
            ],
            ALLARME_CONFERMA: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, allarme_step_conferma),
            ],
        },
        fallbacks=[CommandHandler("annulla", allarme_annulla)],
        allow_reentry=True,
    )
 
    return [
    conv_start,
    conv_allarme,
    CommandHandler("help",       help_cmd),
    CommandHandler("status",     status_cmd),
    CommandHandler("allarmi",    allarmi_cmd),
    CommandHandler("io",         io_cmd),
    CommandHandler("utenti",     utenti_cmd),
    CommandHandler("blacklist",  blacklist_cmd),
    CommandHandler("blocca",     blocca_cmd),
    CommandHandler("sblocca",    sblocca_cmd),
    CommandHandler("rispondi",   rispondi_cmd),
    MessageHandler(filters.TEXT & ~filters.COMMAND, messaggio_sconosciuto),
]
