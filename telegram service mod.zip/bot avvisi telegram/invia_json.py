import os
import json
import httpx
import shutil
import time
from datetime import datetime

# Cartelle
CARTELLA = "risposte_utenti"
CARTELLA_INVIATI = "risposte_inviate"
CARTELLA_IGNORATI = "risposte_ignorate"

# Endpoint FastAPI
ENDPOINT = "http://localhost:8000/risposte"

# Creazione cartelle
os.makedirs(CARTELLA_INVIATI, exist_ok=True)
os.makedirs(CARTELLA_IGNORATI, exist_ok=True)

def log(msg):
    print(f"[{datetime.now().isoformat()}] {msg}")

def valida_json(data):
    campi = ["utente", "telefono", "risposta", "timestamp", "ruolo"]
    return all(c in data for c in campi)

def sposta(file, destinazione):
    shutil.move(file, os.path.join(destinazione, os.path.basename(file)))

def processa_file(filepath):
    filename = os.path.basename(filepath)

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        log(f"ERRORE lettura {filename}: {e}")
        sposta(filepath, CARTELLA_IGNORATI)
        return

    if not valida_json(data):
        log(f"ERRORE struttura JSON non valida → {filename}")
        sposta(filepath, CARTELLA_IGNORATI)
        return

    if data.get("ruolo") != "admin":
        log(f"IGNORATO: utente non admin → {data.get('utente')}")
        sposta(filepath, CARTELLA_IGNORATI)
        return

    try:
        response = httpx.post(ENDPOINT, json={
    "nome": data.get("utente"),
    "risposta": data.get("risposta")
}, timeout=10)
        if response.status_code == 200:
            log(f"OK: risposta inviata → {filename}")
            sposta(filepath, CARTELLA_INVIATI)
        else:
            log(f"ERRORE API ({response.status_code}): {response.text}")
    except Exception as e:
        log(f"ERRORE rete: {e}")

def main():
    log("🔄 Monitor JSON attivo. In attesa di nuovi file...")

    while True:
        files = [f for f in os.listdir(CARTELLA) if f.endswith(".json")]

        for filename in files:
            filepath = os.path.join(CARTELLA, filename)
            processa_file(filepath)

        time.sleep(1)  # controlla ogni secondo

if __name__ == "__main__":
    main()
